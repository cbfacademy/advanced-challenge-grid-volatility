"""
Residual-demand strategy for the 3pm bet  (one command, no manual steps)

    python src/residual_demand_strategy.py

HYPOTHESIS (as tested)
  When forecast residual demand (demand - wind - solar - interconnector imports) is unusually
  HIGH for that time of day, the final price (cashout) will land ABOVE the 3pm half-hourly
  auction price, so we BUY 25MW at 3pm. When it is unusually LOW, cashout will land BELOW the
  3pm price, so we SELL 25MW. Otherwise we stay flat.

THE BET
  profit per half-hour = 0.5 * position_MW * (cashout_price - da_hh_epex_price)
  (we only trade at 3pm: the 9am position is always 0MW)

TIMING / LEAKAGE RULES
  * Only columns with "forecast" in the name are used as signal inputs (CHALLENGE.md: the
    third-party forecasts were all available before the 9am auction the day before delivery).
  * "Unusually high/low" = percentile of today's value among the PREVIOUS 365 days at the same
    local half-hour of the day. Today is never in its own comparison set.
  * Fuel prices are only used in one optional, rejected check (see ALTERNATIVES).

OUTPUTS (all regenerated on every run)
  results/residual_demand/*.csv, key_numbers.json, dashboard.html
  results/figures/*.png
"""
from __future__ import annotations

import json
import matplotlib

matplotlib.use("Agg")  # no display needed
import matplotlib.pyplot as plt
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd
from numpy.lib.stride_tricks import sliding_window_view

pd.set_option("display.width", 250)
pd.set_option("display.max_columns", 40)

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FC = DATA / "3rd_Party_Forecasts"
if not FC.exists():
    FC = DATA / "3rd Party Forecasts"
OUT = ROOT / "results" / "residual_demand"
FIG = ROOT / "results" / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

MAX_MW = 25
WINDOW = 365           # days of history used to judge "unusual" for a given half-hour of the day
MIN_HIST = 180         # minimum usable past values inside that window
EXCLUDE_YEARS = [2021, 2022]   # gas price crisis
SPLIT_YEAR = 2022      # first year of the "second half" robustness check

# strategy keys -> plain-English names (used in tables, charts and dashboard)
NAMES = {
    "sell_only": "Recommended: sell 25 MW when supply is loosest, otherwise do nothing",
    "rule": "Original idea: buy when tight, sell when loose",
    "short": "Always sell 25 MW",
    "long": "Always buy 25 MW",
    "flat": "Do nothing (0 MW)",
}
LEGEND = {
    "sell_only": "Recommended: sell 25 MW only when supply is loosest",
    "rule": "Original idea: buy when tight, sell when loose",
    "short": "Always sell 25 MW",
    "long": "Always buy 25 MW",
    "flat": "Do nothing (0 MW)",
}
COLOURS = {"sell_only": "#0f766e", "rule": "#334155", "short": "#4338ca", "long": "#c2410c", "flat": "#94a3b8"}


# ======================================================================================
# 1. LOAD  (price columns + only columns with "forecast" in the name)
# ======================================================================================
def load() -> pd.DataFrame:
    con = duckdb.connect()
    df = con.sql(f"""
        SELECT
            p.delivery_start_utc,
            TRY_CAST(p.da_hh_epex_price AS DOUBLE)           AS hh_price,
            TRY_CAST(p.cashout_price AS DOUBLE)              AS cashout,
            TRY_CAST(d.demand_forecast_ndf AS DOUBLE)        AS demand_fc,
            TRY_CAST(g.wind_forecast AS DOUBLE)              AS wind_fc,
            TRY_CAST(g.solar_forecast AS DOUBLE)             AS solar_fc,
            TRY_CAST(g.interconnectors_forecast AS DOUBLE)   AS import_fc
        FROM read_parquet('{(DATA / "market_prices.parquet").as_posix()}')              p
        LEFT JOIN read_parquet('{(FC / "demand_forecasts.parquet").as_posix()}')        d USING (delivery_start_utc)
        LEFT JOIN read_parquet('{(FC / "generation_forecasts.parquet").as_posix()}')    g USING (delivery_start_utc)
        ORDER BY p.delivery_start_utc
    """).df()

    # Europe/London clock: "same half-hour of the day" and calendar-year P&L both use it
    local = df["delivery_start_utc"].dt.tz_convert("Europe/London")
    df["date"] = local.dt.normalize().dt.tz_localize(None)
    df["year"] = local.dt.year
    df["sp_key"] = local.dt.hour * 2 + local.dt.minute // 30

    # fuel prices: daily, real header is on the 2nd row (read only for the optional SRMC check)
    fuel = pd.read_excel(DATA / "fuel_prices.xlsx", header=1)
    fuel = fuel.rename(columns={"UK Power Day": "date", "UK CCGT SRMC (£/MWh)": "srmc"})[["date", "srmc"]]
    fuel["date"] = pd.to_datetime(fuel["date"]).dt.normalize()
    return df.merge(fuel, on="date", how="left")


# ======================================================================================
# 2. SIGNAL  (percentile of today vs the previous year, same half-hour of the day)
# ======================================================================================
def rolling_pct_rank(values: np.ndarray) -> np.ndarray:
    """Percentile of each value among the previous WINDOW values (itself excluded)."""
    n = len(values)
    out = np.full(n, np.nan)
    if n <= WINDOW:
        return out
    win = sliding_window_view(values, WINDOW + 1)      # each row: WINDOW past values + today
    past, today = win[:, :-1], win[:, -1]
    valid = np.isfinite(past).sum(axis=1)
    less = np.nansum(past < today[:, None], axis=1)
    ties = np.nansum(past == today[:, None], axis=1)
    rank = (less + 0.5 * ties) / np.where(valid > 0, valid, np.nan)
    rank[(valid < MIN_HIST) | ~np.isfinite(today)] = np.nan
    out[WINDOW:] = rank
    return out


def add_signal(frame: pd.DataFrame, col: str, name: str) -> None:
    frame[name] = np.nan
    for _, idx in frame.groupby("sp_key").groups.items():
        sub = frame.loc[idx].sort_values("date")
        frame.loc[sub.index, name] = rolling_pct_rank(sub[col].to_numpy(float))


def build_signal(df: pd.DataFrame) -> pd.DataFrame:
    df["move"] = df["cashout"] - df["hh_price"]                       # £/MWh earned per MW long at 3pm
    df["resid"] = df["demand_fc"] - df["wind_fc"] - df["solar_fc"] - df["import_fc"]
    df["hh_vs_srmc"] = df["hh_price"] - df["srmc"]
    add_signal(df, "resid", "resid_rank")
    add_signal(df, "hh_vs_srmc", "srmc_rank")
    d = df.dropna(subset=["move", "resid_rank"]).copy()               # same rows for every strategy
    d["quintile"] = pd.cut(d["resid_rank"], [0, .2, .4, .6, .8, 1.0], labels=[1, 2, 3, 4, 5],
                           include_lowest=True).astype(int)
    return d


# ======================================================================================
# 3. STRATEGIES AND METRICS
# ======================================================================================
def add_positions(d: pd.DataFrame) -> None:
    q = d["quintile"]
    pos = {
        "rule": np.select([q == 5, q == 1], [MAX_MW, -MAX_MW], 0),
        "sell_only": np.where(q == 1, -MAX_MW, 0),
        "short": np.full(len(d), -MAX_MW),
        "long": np.full(len(d), MAX_MW),
        "flat": np.zeros(len(d)),
        # --- alternatives, tested after seeing the full-sample results (disclosed in the memo) ---
        "alt_sell_bottom40": np.where(q <= 2, -MAX_MW, 0),
        "alt_sell_all_but_top20": np.where(q <= 4, -MAX_MW, 0),
        "alt_sell_scaled": -MAX_MW * (1 - d["resid_rank"].to_numpy()),
    }
    for k, v in pos.items():
        d[f"pos_{k}"] = v
        d[f"pnl_{k}"] = 0.5 * v * d["move"]
    # optional gas-cost filter on the original rule (rejected)
    s_ok = d["srmc_rank"].notna()
    srmc_pos = np.select([(q == 5) & (d["srmc_rank"] <= .5), (q == 1) & (d["srmc_rank"] >= .5)], [MAX_MW, -MAX_MW], 0)
    d["pos_alt_srmc_filter"] = np.where(s_ok, srmc_pos, 0)
    d["pnl_alt_srmc_filter"] = 0.5 * d["pos_alt_srmc_filter"] * d["move"]
    d["srmc_ok"] = s_ok


def metrics(d: pd.DataFrame, key: str) -> dict:
    pnl, pos = d[f"pnl_{key}"], d[f"pos_{key}"]
    day = pnl.groupby(d["date"]).sum()
    traded = pos != 0
    traded_days = traded.groupby(d["date"]).any()          # days where we actually held a position
    mwh = (0.5 * pos.abs()).sum()
    sd = day.std()
    return {
        "total_gbp": pnl.sum(),
        "half_hours_traded": int(traded.sum()),
        "days_traded": int(traded_days.sum()),
        "win_rate_pct_when_traded": (pnl[traded] > 0).mean() * 100 if traded.any() else np.nan,
        "gbp_per_MWh_traded": pnl.sum() / mwh if mwh > 0 else np.nan,
        "worst_day_gbp": day.min(),
        "max_drawdown_gbp": (day.cumsum() - day.cumsum().cummax()).min(),
        "profitable_days_pct_of_days_traded": (day[traded_days] > 0).mean() * 100 if traded_days.any() else np.nan,
        "annualised_sharpe": day.mean() / sd * np.sqrt(365) if sd > 0 else np.nan,
        "daily_t_stat": day.mean() / (sd / np.sqrt(len(day))) if sd > 0 else np.nan,
    }


def windows(d: pd.DataFrame) -> dict:
    return {
        "All years": d,
        "Excluding 2021-22": d[~d["year"].isin(EXCLUDE_YEARS)],
        f"First half (to {SPLIT_YEAR - 1})": d[d["year"] < SPLIT_YEAR],
        f"Second half ({SPLIT_YEAR} on)": d[d["year"] >= SPLIT_YEAR],
    }


# ======================================================================================
# 4. FIGURES
# ======================================================================================
def style():
    plt.rcParams.update({
        "figure.facecolor": "white", "axes.facecolor": "white", "axes.edgecolor": "#cbd5e1",
        "axes.grid": True, "grid.color": "#e2e8f0", "grid.linewidth": .8, "axes.axisbelow": True,
        "axes.spines.top": False, "axes.spines.right": False, "font.size": 11,
        "axes.titlesize": 13, "axes.titleweight": "bold", "axes.titlelocation": "left",
    })


def gbp_k(x, _=None):
    return f"{'-' if x < 0 else ''}£{abs(x) / 1000:,.0f}k"


def fig_cumulative(d: pd.DataFrame):
    style()
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(10, 7.6), sharex=True, gridspec_kw={"height_ratios": [3, 1.6]})
    order = ["short", "sell_only", "rule", "flat", "long"]
    ends = {}
    for k in order:
        day = d[f"pnl_{k}"].groupby(d["date"]).sum()
        cum = day.cumsum()
        lw = 3 if k == "sell_only" else 2
        a1.plot(cum.index, cum.values, color=COLOURS[k], lw=lw, label=LEGEND[k])
        ends[k] = cum.iloc[-1]
        if k in ("sell_only", "rule", "short"):
            dd = (cum - cum.cummax()).values
            if k != "rule":
                a2.fill_between(cum.index, dd, 0, color=COLOURS[k], alpha=.55 if k == "sell_only" else .18, lw=0)
            a2.plot(cum.index, dd, color=COLOURS[k], lw=1.6 if k == "sell_only" else 1.1)
    for yr in EXCLUDE_YEARS[:1]:
        for ax in (a1, a2):
            ax.axvspan(pd.Timestamp("2021-01-01"), pd.Timestamp("2022-12-31"), color="#fde68a", alpha=.25, lw=0)
    a1.text(pd.Timestamp("2022-01-01"), a1.get_ylim()[1] * .93, "2021-22 gas crisis", ha="center", fontsize=9, color="#92400e")
    a1.set_title("Running profit from the 3pm bet, 25 MW position")
    a1.set_ylabel("Total profit so far")
    a1.yaxis.set_major_formatter(gbp_k)
    a1.legend(loc="upper left", frameon=False, fontsize=9.5)
    a2.set_title("How far below its previous best each strategy fell (drawdown)", fontsize=11)
    a2.set_ylabel("Loss from peak")
    a2.yaxis.set_major_formatter(gbp_k)
    fig.tight_layout()
    fig.savefig(FIG / "01_running_profit_and_drawdown.png", dpi=150)
    plt.close(fig)


def fig_quintiles(d: pd.DataFrame, qt: pd.DataFrame):
    style()
    fig, ax = plt.subplots(figsize=(10, 4.4))
    labels = ["1\nLoosest 20%", "2", "3\nMiddle", "4", "5\nTightest 20%"]
    vals = qt["avg_move_gbp_per_MWh"].to_numpy()
    se = qt["std_error_gbp_per_MWh"].to_numpy()   # standard error from one average per day (approximate)
    cols = [COLOURS["sell_only"] if v < 0 else COLOURS["long"] for v in vals]
    ax.bar(range(5), vals, color=cols, width=.62, yerr=1.96 * se, capsize=5, ecolor="#475569")
    ax.axhline(0, color="#475569", lw=1)
    top = max(vals.max() + 1.96 * se.max(), 1) * 1.05
    ax.set_ylim(min(vals.min() - 1.96 * se.max(), -1) * 1.05, top * 1.12)
    for i, v in enumerate(vals):
        ax.text(i, top * 1.04, f"{'+' if v >= 0 else '-'}£{abs(v):.2f}", ha="center", va="bottom", fontweight="bold", fontsize=12)
    ax.set_xticks(range(5), labels)
    ax.set_xlabel("How tight supply was forecast to be, compared with the same time of day over the past year")
    ax.set_ylabel("Final price minus 3pm price (£/MWh)")
    ax.set_title("Loose supply reliably pulls the final price below 3pm; tight supply does not reliably lift it", pad=26)
    ax.text(.995, .03, "Bars: average gap.  Whiskers: 95% range of uncertainty (from daily averages).\n"
            "Below zero = a seller at 3pm made money on average.", transform=ax.transAxes, fontsize=9,
            color="#475569", ha="right", va="bottom")
    fig.tight_layout()
    fig.savefig(FIG / "02_price_move_by_supply_tightness.png", dpi=150)
    plt.close(fig)


def fig_legs(legs: pd.DataFrame):
    style()
    fig, ax = plt.subplots(figsize=(10, 4.4))
    yrs = [y for y in legs.index if isinstance(y, int)]
    x = np.arange(len(yrs))
    ax.bar(x - .2, legs.loc[yrs, "sell_leg"], .38, color=COLOURS["sell_only"], label="Selling when supply is loose")
    ax.bar(x + .2, legs.loc[yrs, "buy_leg"], .38, color=COLOURS["long"], label="Buying when supply is tight")
    ax.axhline(0, color="#475569", lw=1)
    ax.set_xticks(x, [str(y) for y in yrs])
    ax.yaxis.set_major_formatter(gbp_k)
    ax.set_ylabel("Profit in the year")
    ax.set_title("The original idea's profit comes from selling; the buying half is unreliable")
    ax.legend(frameon=False, loc="upper center", bbox_to_anchor=(.5, -.1), ncol=2)
    fig.tight_layout()
    fig.savefig(FIG / "03_selling_vs_buying_by_year.png", dpi=150)
    plt.close(fig)


# ======================================================================================
# 5. MAIN
# ======================================================================================
def main():
    df = load()
    d = build_signal(df)
    add_positions(d)
    first, last = d["date"].min(), d["date"].max()
    print(f"Sample: {len(d):,} half-hours, {first:%Y-%m-%d} to {last:%Y-%m-%d} "
          f"({d['date'].nunique():,} days). First 365 days are warm-up for the signal.")

    # ---- A. five groups -------------------------------------------------------------
    daily = d.groupby(["quintile", "date"])["move"].mean().reset_index()
    rows = []
    for q, g in d.groupby("quintile"):
        dm = daily.loc[daily["quintile"] == q, "move"]
        rows.append({"group": q, "half_hours": len(g), "avg_move_gbp_per_MWh": g["move"].mean(),
                     "median_move_gbp_per_MWh": g["move"].median(),
                     "pct_half_hours_final_above_3pm": (g["move"] > 0).mean() * 100,
                     "t_stat": dm.mean() / (dm.std() / np.sqrt(len(dm))),
                     "std_error_gbp_per_MWh": dm.std() / np.sqrt(len(dm))})
    qt = pd.DataFrame(rows).set_index("group")
    qt_ex = (d[~d["year"].isin(EXCLUDE_YEARS)].groupby("quintile")["move"].mean()).rename("avg_move_ex_2021_22")
    qt = qt.join(qt_ex)
    qt.round(3).to_csv(OUT / "quintile_table.csv")
    print("\n=== A. Average (final price - 3pm price) by supply-tightness group; 1 = loosest, 5 = tightest")
    print(qt.round(2))

    # ---- B/C. strategy comparison -----------------------------------------------------
    main_keys = ["sell_only", "rule", "short", "long", "flat"]
    alt_keys = ["alt_sell_bottom40", "alt_sell_scaled", "alt_sell_all_but_top20"]
    recs = []
    for wname, w in windows(d).items():
        for k in main_keys + alt_keys:
            recs.append({"window": wname, "strategy": k, **metrics(w, k)})
        ws = w[w["srmc_ok"]]
        recs.append({"window": wname, "strategy": "alt_srmc_filter", **metrics(ws, "alt_srmc_filter")})
    summary = pd.DataFrame(recs)
    summary.round(2).to_csv(OUT / "strategy_summary.csv", index=False)
    for wname in windows(d):
        print(f"\n=== B/C. Strategy comparison - 3pm bet - {wname}")
        print(summary[summary.window == wname].drop(columns="window").set_index("strategy").round(2))

    # ---- year by year ---------------------------------------------------------------
    keys_y = main_keys + alt_keys + ["alt_srmc_filter"]
    by_year = pd.DataFrame({k: d.groupby("year")[f"pnl_{k}"].sum() for k in keys_y})
    by_year.loc["Total"] = by_year.sum()
    by_year.loc["Total ex 2021-22"] = by_year.drop(index=["Total"] + EXCLUDE_YEARS).sum()
    by_year.round(0).to_csv(OUT / "profit_by_year.csv")
    print("\n=== Profit by calendar year (GBP)")
    print(by_year[main_keys].round(0))

    # ---- month by month (feeds the dashboard) ------------------------------------------
    d["ym"] = d["date"].dt.strftime("%Y-%m")
    by_month = pd.DataFrame({k: d.groupby("ym")[f"pnl_{k}"].sum() for k in main_keys})
    by_month.round(0).to_csv(OUT / "profit_by_month.csv")

    # ---- buy leg vs sell leg of the original rule ----------------------------------------
    r = d["pnl_rule"]
    legs = pd.DataFrame({"sell_leg": r.where(d["pos_rule"] < 0, 0).groupby(d["year"]).sum(),
                         "buy_leg": r.where(d["pos_rule"] > 0, 0).groupby(d["year"]).sum()})
    legs.loc["Total"] = legs.sum()
    legs.loc["Total ex 2021-22"] = legs.drop(index=["Total"] + EXCLUDE_YEARS).sum()
    legs.round(0).to_csv(OUT / "rule_buy_vs_sell_leg_by_year.csv")
    print("\n=== Original rule split into its legs (GBP)")
    print(legs.round(0))
    print(f"\nAverage final-minus-3pm price across all sample half-hours: {d['move'].mean():.2f} GBP/MWh")

    # ---- figures, dashboard, key numbers -----------------------------------------------
    legs_int = legs.copy()
    fig_cumulative(d)
    fig_quintiles(d, qt.rename(columns={}))
    fig_legs(legs_int)
    write_dashboard(by_month, d)

    s_all = summary[summary.window == "All years"].set_index("strategy")
    s_ex = summary[summary.window == "Excluding 2021-22"].set_index("strategy")
    key = {
        "sample_first_day": f"{first:%Y-%m-%d}", "sample_last_day": f"{last:%Y-%m-%d}",
        "half_hours": int(len(d)), "avg_move_all": float(d["move"].mean()),
        "all_years": s_all.round(4).to_dict(orient="index"),
        "ex_2021_22": s_ex.round(4).to_dict(orient="index"),
        "windows": {w: summary[summary.window == w].set_index("strategy").round(4).to_dict(orient="index")
                    for w in windows(d)},
        "profit_by_year": by_year.round(0).to_dict(orient="index"),
        "legs": legs.round(0).to_dict(orient="index"),
        "quintiles": qt.round(4).to_dict(orient="index"),
    }
    (OUT / "key_numbers.json").write_text(json.dumps(key, indent=1, default=float))
    print(f"\nWrote tables + key_numbers.json to {OUT.relative_to(ROOT)}, charts to {FIG.relative_to(ROOT)}")


def write_dashboard(by_month: pd.DataFrame, d: pd.DataFrame):
    tpl = (Path(__file__).parent / "dashboard_template.html").read_text(encoding="utf-8")
    m = by_month.reset_index()
    g = d.groupby(["year", "quintile"])["move"].agg(["mean", "size"])
    qmean, qn = {}, {}
    for y in sorted(d["year"].unique()):
        qmean[str(y)] = [round(float(g.loc[(y, k), "mean"]), 3) if (y, k) in g.index else None for k in range(1, 6)]
        qn[str(y)] = [int(g.loc[(y, k), "size"]) if (y, k) in g.index else 0 for k in range(1, 6)]
    data = {"months": {c: (m[c].round(0).tolist() if c != "ym" else m[c].tolist()) for c in m.columns},
            "qmean": qmean, "qn": qn}
    (OUT / "dashboard.html").write_text(tpl.replace("__DATA__", json.dumps(data, separators=(",", ":"))), encoding="utf-8")


if __name__ == "__main__":
    main()
