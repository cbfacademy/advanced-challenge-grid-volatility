"""
Reproduction check: compares the headline numbers quoted in DECISION_MEMO.md with the numbers
the pipeline just produced (results/residual_demand/key_numbers.json).

    python src/residual_demand_strategy.py
    python src/check_headlines.py          # prints PASS/FAIL per line, exit code 1 on any FAIL
"""
import json
import sys
from pathlib import Path

K = json.loads((Path(__file__).resolve().parents[1] / "results" / "residual_demand" / "key_numbers.json").read_text())
A, X = K["all_years"], K["ex_2021_22"]

# (description, value from this run, value quoted in the memo, tolerance)
CHECKS = [
    ("Recommended: total profit (GBP)", A["sell_only"]["total_gbp"], 1_133_088, 5),
    ("Recommended: profit without 2021-22", X["sell_only"]["total_gbp"], 789_767, 5),
    ("Recommended: worst day", A["sell_only"]["worst_day_gbp"], -40_109, 5),
    ("Recommended: biggest fall from peak", A["sell_only"]["max_drawdown_gbp"], -132_383, 5),
    ("Recommended: Sharpe", A["sell_only"]["annualised_sharpe"], 1.26, 0.006),
    ("Recommended: GBP per MWh sold", A["sell_only"]["gbp_per_MWh_traded"], 2.19, 0.006),
    ("Original rule: total profit", A["rule"]["total_gbp"], 1_265_296, 5),
    ("Original rule: biggest fall", A["rule"]["max_drawdown_gbp"], -344_225, 5),
    ("Always sell: total profit", A["short"]["total_gbp"], 2_546_534, 5),
    ("Always sell: worst day", A["short"]["worst_day_gbp"], -428_650, 5),
    ("Always sell: biggest fall", A["short"]["max_drawdown_gbp"], -668_462, 5),
    ("Always buy: total profit", A["long"]["total_gbp"], -2_546_534, 5),
    ("Loosest group avg move (GBP/MWh)", K["quintiles"]["1"]["avg_move_gbp_per_MWh"], -2.19, 0.006),
    ("Tightest group avg move (GBP/MWh)", K["quintiles"]["5"]["avg_move_gbp_per_MWh"], 0.35, 0.006),
    ("Average move, all half-hours", K["avg_move_all"], -1.20, 0.006),
    ("Original rule buy leg total", K["legs"]["Total"]["buy_leg"], 132_209, 5),
    ("Original rule sell leg total", K["legs"]["Total"]["sell_leg"], 1_133_088, 5),
    ("Half-hours in sample", K["half_hours"], 169_943, 0),
]
bad = 0
for name, got, want, tol in CHECKS:
    ok = abs(got - want) <= tol
    bad += not ok
    print(f"{'PASS' if ok else 'FAIL'}  {name:42s} run={got:>14,.2f}  memo={want:>14,.2f}")
print(f"\n{len(CHECKS) - bad}/{len(CHECKS)} headline numbers match DECISION_MEMO.md")
sys.exit(1 if bad else 0)
