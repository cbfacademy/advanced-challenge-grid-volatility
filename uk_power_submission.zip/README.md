# Grid Volatility Challenge

Welcome to the Grid Volatility Challenge! This repo contains everything you need to get started. 

## The Challenge

**Full challenge requirements:** see [`CHALLENGE.md`](docs/CHALLENGE.md).

## Our submission: residual-demand strategy for the 3pm bet

**Read first:** [`DECISION_MEMO.md`](DECISION_MEMO.md) (hypothesis, recommendation, trade-offs, metrics and kill conditions).

**In one line:** when forecast residual demand (demand - wind - solar - imports) is in the loosest 20% for that time of day, sell 25 MW at the 3pm auction and hold to cashout; otherwise stay at 0 MW. We tested the original buy-and-sell version too, and the buying half did not hold up.

### Reproduce it (two commands, no manual steps)

```bash
pip install -r requirements.txt
python src/residual_demand_strategy.py      # about 5-10 seconds
python src/check_headlines.py               # optional: confirms the numbers quoted in the memo
```

Run them from the repo root (the scripts also work from any folder). The data files in `data/` are used as supplied: the script reads `market_prices.parquet`, `3rd_Party_Forecasts/demand_forecasts.parquet`, `3rd_Party_Forecasts/generation_forecasts.parquet` and `fuel_prices.xlsx` (read with `header=1`). Nothing is downloaded and no Elexon feeds are used.

### What you should see

The console prints, in order: the five-group table (average final-minus-3pm price by how tight supply was forecast to be), the comparison of the strategies against always-sell, always-buy and do-nothing for all years, without 2021-22 and for each half of the sample, profit by calendar year, and the buy/sell split of the original rule. Headline results (25 MW, before trading costs):

| 3pm bet, Dec 2016 to Oct 2026 | Total profit | Worst day | Biggest fall from a peak |
|---|---:|---:|---:|
| Recommended: sell only when loose | £1,133,088 | -£40,109 | -£132,383 |
| Original: buy when tight, sell when loose | £1,265,296 | -£107,531 | -£344,225 |
| Always sell 25 MW | £2,546,534 | -£428,650 | -£668,462 |
| Always buy 25 MW | -£2,546,534 | -£168,406 | -£2,699,719 |
| Do nothing | £0 | £0 | £0 |

`check_headlines.py` should print `18/18 headline numbers match DECISION_MEMO.md`.

### Files it writes

| File | What it is |
|---|---|
| `results/figures/01_running_profit_and_drawdown.png` | Running profit and drawdown of every strategy |
| `results/figures/02_price_move_by_supply_tightness.png` | Average price move in each of the five groups |
| `results/figures/03_selling_vs_buying_by_year.png` | Selling vs buying half of the original rule, by year |
| `results/residual_demand/dashboard.html` | Interactive view with Month/Year and "leave out 2021-22" toggles (open in a browser; needs internet for the chart library) |
| `results/residual_demand/strategy_summary.csv` | Every metric for every strategy and period |
| `results/residual_demand/profit_by_year.csv`, `profit_by_month.csv` | Profit tables |
| `results/residual_demand/quintile_table.csv` | The five-group table |
| `results/residual_demand/rule_buy_vs_sell_leg_by_year.csv` | Buy/sell split of the original rule |
| `results/residual_demand/key_numbers.json` | All headline numbers in one file |

### How it works (and what stops it cheating)

1. **Signal:** `residual demand = demand_forecast_ndf - wind_forecast - solar_forecast - interconnectors_forecast`. Only columns with "forecast" in the name are used. It is ranked against the previous 365 days at the same London-time half-hour of the day; today is never in its own comparison set. The first year of data is warm-up, so results start on 31 Dec 2016.
2. **Groups:** half-hours are split into five equal groups by that rank (1 = loosest, 5 = tightest).
3. **Bet:** `profit = 0.5 x position_MW x (cashout_price - da_hh_epex_price)`. The 9am position is always 0 MW.
4. **Rule:** sell 25 MW in group 1, otherwise 0 MW. The original rule also buys 25 MW in group 5.
5. **Comparison:** every strategy is scored on the same half-hours. Years are London calendar years. "Excluding 2021-22" drops those two years entirely.

### Data notes (found while checking)

- The files cannot prove when each forecast was published (`downloaded_at_utc` is a bulk download time), so we rely on `docs/CHALLENGE.md`, which says all third-party forecasts existed before the 9am auction.
- `solar_forecast` in `generation_forecasts.parquet` is tiny (about 39 MW on average), as demand is already net of embedded solar.
- In `gfs_renewables_forecast.parquet` the `wind_forecast` and `solar_forecast` columns look swapped (the "wind" column peaks at midday and the "solar" column has no day/night pattern). We do not use that file.
- `src/data_analysis.py` is an earlier exploration script and is unchanged.

---

## Prerequisites 
- Python 3.12
- `pip` - comes with Python 
- Git for cloning the repo

**Python Version**: This project is pinned to **Python 3.12** via `.python-version`. This is to avoid build failures with scientific libraries should you choose to use them (pandas, NumPy, DubkDB). 

If you use `pyenv` or `pyenv-win`, it will be selected automatically. You can modify or remove this file intend to update the project's Python version. 

### Installing Python

**macOS (Homebrew):**

```bash
brew install python@3.12
```

**Windows:**

Download the Python 3.12 executable directly from [`python.org/downloads`](python.org/downloads) and run the installer. Ensure you check the box that says "Add python.exe to PATH" during setup. 

## Getting Started

### 1. Fork the repo
Click "Fork" in the top-right of the GitHub repo page, then clone your fork:
```bash
git clone https://github.com/<your-username>/advanced-challenge-grid-volatility.git
cd advanced-challenge-grid-volatility
```

### 2. Create a Virtual Environment

macOS / Linux:
```bash
python3.12 -m venv venv
source venv/bin/activate
```

Windows (PowerShell):
```powershell
py -3.12 -m venv venv
.\venv\Scripts\Activate.ps1
```

Windows (Command Prompt):
```cmd
py -3.12 -m venv venv
venv\Scripts\activate.bat
```

You should see `venv` at the start of your terminal prompt, indicating the environment is active.

### 3. Install Dependencies
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

*Note: SQLite is built into Python. No installation required.*

## First price-spread baseline

After installing the requirements, run:

```bash
python src/xgboost_baseline.py
```

If XGBoost cannot find MacPorts' OpenMP library, run it with:

```bash
DYLD_LIBRARY_PATH=/opt/local/lib/libomp python src/xgboost_baseline.py
```

This trains a basic XGBoost regressor to predict the half-hourly auction minus
hourly auction price (`da_hh_epex_price - da_hr_epex_price`). It uses the NDF
demand forecast, wind and solar forecasts, residual demand, and local delivery
time features. Elexon datasets are excluded entirely; only the NDF demand and
GFS renewables forecasts are inputs. It filters every input dataset to delivery
periods from 2019-01-01 onward, when wind forecasts are available.
UTC delivery timestamps are converted to Europe/London time for delivery-hour
features, date splits, and daily P&L reporting. The script trains on the
earliest 80% of complete delivery dates and reports an out-of-time test against
the challenge's fixed-position benchmarks. The predicted spread's sign sets a
±25MW 9am position, which is held through cashout without a 3pm adjustment.
Each run appends the model metrics and strategy benchmark P&L to
`results/xgboost_baseline_performance.csv`. It also compares the same model
with and without the residual-demand feature on the same chronological
holdout, appending HH-HR spread metrics to
`results/xgboost_residual_demand_ablation.csv`.